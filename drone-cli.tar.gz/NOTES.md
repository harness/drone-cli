
https://github.com/creack/multio


inject
parse
scrub
prune
matrix

parse
parse/matrix

_drone_type
_drone_tags
_drone_order
_drone_build

1. put all containers into buckets
2. run containers in specific buckets



build := builder.New()
for _, container := range containers {
	switch container.Type {
	case "setup", "clone", "build":
		build.Register(builder.Batch(container, environment))
	case "service":
		build.Register(builder.Service(container, environment))
	}
}
build.Run(req, res)

after := builder.New()
for _, container := range containers {
	switch container.Type {
	case "publish", "deploy":
		after.Register(builder.Batch(container, environment))
	}
}
after.Run(req, res)

always := builder.New()
for _, container := range containers {
	switch container.Type {
	case "notify":
		always.Register(builder.Batch(container, environment))
	}
}
always.Run(req, res)





docker:
	image: docker
	build:
		file: path/to/Dockerfile
		name: foo/bar:baz
		pull: false
	push:
		index: index.foo.com
		token: baz



amazon_s3
amazon_ec2

google_storage
google_compute
google_container_engine
google_appengine_go
google_appengine_php
google_appengine_python
google_appengine_python

azure_storage
azure_compute

rackspace_storage
rackspace_compute

openstack_swift
openstack_compute

digital_ocean

kubernetes

heroku

deis

git_push

github_release


rsync:
	image: rsync
	remote:
		user: foo
		host: 0.0.0.0
		delete: true
		source: path/in/container
		destination: path/in/host
		recursive: true
	commands:
		- install -t usr/local/bin


builder/
builder/builder.go
builder/request.go
builder/result.go

builder/plugin/

cluster/
cluster/cluster.go
cluster/container.go
cluster/docker/cluster.go
cluster/dockre/helper.go

common/
common/build.go
common/commit.go
common/perm.go
common/repo.go
common/user.go

datastore/
datastore/blob.go
datastore/build.go
datastore/commit.go
datastore/perm.go
datastore/repo.go
datastore/user.go

dispatch/
dispatch/swarm

engine/
eventbus/

remote/
remote/plugin

runner/
runner/runner.go

server/

GOALS:

	* should be able to access logs on-demand 				<-- HARD
	* should be able to cluster the drone server, no in-memory state 	<-- HARD. Will need to rely on naming convention to stream data, I guess :(

	* should be able to use swarm
	* should be able to use a remote queue


CONCEPTS:

	* client - docker client running the build
	* builder - thing that runs a build
	* config - build configuration
	* step - build step
	* container - docker container to execute the step

	* queue - available containers

	* environment - everything going on in the system (see https://github.com/mitchellh/packer/blob/3ff514bb4435a16d8aa0ced8c43c5f49215d94e9/packer/environment.go)


// parse config file
// inject variables
// scrub to prevent leakage

// strip config of steps that should not be executed


OPTION 1:

	multiplex the build output (BAD)

OPTION 2: 

	naming convention to connect on-demand

type Build struct {
	Started
	Finished
	ExitCode
}

type Builder interface {
	Push(Task)
	PushDaemon
	PushDeploy
	PushNotify

	Run()
	RunDaemon()
	RunDeploy()
	RunPublish()
	RunNotify()

	Build() (*Build, error)
	Logs()
	Setup()
	Teardown()
}

type Prepare func(Cluster, Request)

PrepareClone
PrepareBuild
PreparePublish
PrepareDeploy
PrepareNotify


// cloner
// builder
// deployer
// notifier

func Clone(e Environment, c Config)
func Build(e Environment, c Config)
func Publish(e Environment, c Config)
func Deploy(e Environment, c Config)
func Notify(e Environment, c Config)

Runner{
	client *Client
	config *Config
	
	ambassador *Container
	containers []*Container
}

func Run(req Request, res Result) {
	
}

func Setup() error {
	
}

func Teardown() error {
	
}

func Logs() {
	
}

* start ambassador container
	busybox
	sleep 1d
	set network
	set volume

* run build container
* setup service containers

* run clone, build, publish, deploy
* run notify

* kill all
* delete all






QUESTION 1:  security implications of cache
QUESTION 2:  parallel implications of cache
QUESTION 3:  should we generate a build script? should we send the build script as input args?


 * use --net container by default instead of socat
 * use volume container for git clone
 * use containers for publish, deploy and notify plugins
 * use docker logs for streaming output directly
 * enable docker 'deploy' container with privileged mode (plugin)
 

design goals:

 * run matrix builds
 * wait until builds complete before executing plugins (notification, publish, deploy)
 * eliminate dependencies on socat, git, ssh and others by using the same volume container for all git clones
 * separate build script and other logic from the actual build in Go code
 * use docker logs for fetching output
 * volume container must work with local docker build
 * cache portions of the build 												<****************************************

security goals:

 * PROBLEM: user shouldn't need privileged mode to push to docker index
 * PROBLEM: user shouldn't be able to change the notification section to something malicious in a public, pull request
 * PROBLEM: user shouldn't be able to change to privileged section to something malicious in a public, pull request
 * PROBLEM: user shouldn't be able to change cached directory in a public, pull request 				<****************************************
 * PROBLEM: user shouldn't be able to intercept private variables in a public, pull request
 * PROBLEM: user shouldn't have access to the ssh key or netrc file in a public, pull request
 * NOTE: the above rules for public, pull requests should be loosened for project members






drone
drone-cli
drone-client

drone-go
drone-node

drone-plugin-go
drone-plugin-node


notify:
  slack:
    ...
  email:
    ...
  


drone-plugin-go
drone-plugin-node
drone-plugin-python
drone-plugin-ruby

drone-clone-git
drone-clone-hg

drone-notify-slack
drone-notify-hipchat
drone-notify-gitter
drone-notify-spark
drone-notify-kato
drone-notify-irc

drone-deploy-aws
drone-deploy-gce
drone-deploy-rackspace
drone-deploy-digitalocean
drone-deploy-openstack
drone-deploy-kubernetes
drone-deploy-git
drone-deploy-heroku

drone-publish-bintray
drone-publish-dockerhub
drone-publish-docker
drone-publish-s3
drone-publish-swift
drone-publish-azure-storage
drone-publish-google-storage

drone-report-lcov
drone-report-cobertura
drone-report-clover
drone-report-gocov

drone-generate-deb
drone-generate-rpm
drone-generate-





report:		lcov, xunit, 

publish:	s3, swift, dockerhub, etc

deploy:		


validate - validate the project is correct and all necessary information is available
compile - compile the source code of the project
test - test the compiled source code using a suitable unit testing framework. These tests should not require the code be packaged or deployed
package - take the compiled code and package it in its distributable format, such as a JAR.
integration-test - process and deploy the package if necessary into an environment where integration tests can be run
verify - run any checks to verify the package is valid and meets quality criteria
install - install the package into the local repository, for use as a dependency in other projects locally
deploy 




Encode(map[string]string)

Decode(interface{})



* drone_prepare_{ID}
	* create build script


* drone_clone_{ID}
	* git clone
	* hg blone


* drone_setup_{ID}	<-- can back this up!


* drone_build_{ID}


* drone_email_{ID}




drone/drone

# INIT

	drone/drone-init

# CLONE

	drone/drone-clone-git
	drone/drone-clone-hg

# NOTIFY

	drone/drone-notify-slack
	drone/drone-notify-hipchat
	drone/drone-notify-gitter
	drone/drone-notify-irc
	drone/drone-notify-kato
	drone/drone-notify-flowdock

# PUBLISH

	drone/drone-publish-s3
	drone/drone-publish-azure
	drone/drone-publish-swift
	drone/drone-publish-npm
	drone/drone-publish-pypi
	drone/drone-publish-bintray
	drone/drone-publish-gems
	drone/drone-publish-docker


# DEPLOY

	drone/drone-notify-deis
	drone/drone-notify-heroku
	drone/drone-notify-modulus
	drone/drone-notify-nodejitsu
	drone/drone-notify-git
	drone/drone-notify-cloudfoundry
	drone/drone-notify-appengine-go
	drone/drone-notify-appengine-python
	drone/drone-notify-appengine-php
	drone/drone-notify-kubernetes

