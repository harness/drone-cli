# drone-cli
Drone command-line interface

**NOTE:** this is a special branch being used to test out matrix and parallel builds.
It requires a patched version of the [samalba/dockerclient](https://github.com/samalba/dockerclient)
package found at https://github.com/samalba/dockerclient/pull/74
