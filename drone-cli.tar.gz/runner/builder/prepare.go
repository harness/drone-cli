package builder

/*
type Prep func(runner *Runner, req *Request) error

func PrepClone(runner *Runner, req *Request) error {
	return nil
}

func PrepBuild(runner *Runner, req *Request) error {
	return nil
}

func PrepPublish(runner *Runner, req *Request) error {
	return nil
}

func PrepDeploy(runner *Runner, req *Request) error {
	return nil
}

func PrepNotify(runner *Runner, req *Request) error {
	return nil
}
*/
